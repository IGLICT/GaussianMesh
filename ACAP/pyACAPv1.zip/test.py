import pyACAP
import trimesh
import numpy as np
import time, os

def expR(logR):
    res = np.zeros((logR.shape[0],3,3))
    theta = np.sqrt(logR[:,0,1]*logR[:,0,1]+logR[:,0,2]*logR[:,0,2]+logR[:,1,2]*logR[:,1,2])
    for i in range(logR.shape[0]):
        if(abs(theta[i])==0):
            res[i]=np.eye(3)
        else:
            x=logR[i]/theta[i]
            res[i]=np.eye(3)+x*np.sin(theta[i])+np.matmul(x,x)*(1-np.cos(theta[i]))
    return res

def load_obj(obj_filename):
    """Ref: https://github.com/facebookresearch/pytorch3d/blob/25c065e9dafa90163e7cec873dbb324a637c68b7/pytorch3d/io/obj_io.py
    Load a mesh from a file-like object.
    """
    with open(obj_filename, "r") as f:
        lines = [line.strip() for line in f]

    verts, uvcoords = [], []
    faces, uv_faces = [], []
    # startswith expects each line to be a string. If the file is read in as
    # bytes then first decode to strings.
    if lines and isinstance(lines[0], bytes):
        lines = [el.decode("utf-8") for el in lines]

    for line in lines:
        tokens = line.strip().split()
        if line.startswith("v "):    # Line is a vertex.
            vert = [float(x) for x in tokens[1:4]]
            if len(vert) != 3:
                msg = "Vertex %s does not have 3 values. Line: %s"
                raise ValueError(msg % (str(vert), str(line)))
            verts.append(vert)
        elif line.startswith("vt "):    # Line is a texture.
            tx = [float(x) for x in tokens[1:3]]
            if len(tx) != 2:
                raise ValueError(
                    "Texture %s does not have 2 values. Line: %s" % (str(tx), str(line))
                )
            uvcoords.append(tx)
        elif line.startswith("f "):    # Line is a face.
            # Update face properties info.
            face = tokens[1:]
            face_list = [f.split("/") for f in face]
            for vert_props in face_list:
                # Vertex index.
                faces.append(int(vert_props[0]))
                if len(vert_props) > 1:
                    if vert_props[1] != "":
                        # Texture index is present e.g. f 4/1/1.
                        uv_faces.append(int(vert_props[1]))

    verts = np.array(verts)
    uvcoords = np.array(uvcoords)
    faces = np.array(faces)
    faces = faces.reshape(-1, 3) - 1
    uv_faces = np.array(uv_faces)
    uv_faces = uv_faces.reshape(-1, 3) - 1
    return (verts, uvcoords, faces, uv_faces)

def as_mesh(scene_or_mesh):
    """
    Convert a possible scene to a mesh.

    If conversion occurs, the returned mesh has only vertex and face data.
    """
    if isinstance(scene_or_mesh, trimesh.Scene):
        if len(scene_or_mesh.geometry) == 0:
            mesh = None  # empty scene
        else:
            # we lose texture information here
            mesh = trimesh.util.concatenate(
                tuple(trimesh.Trimesh(vertices=g.vertices, faces=g.faces)
                    for g in scene_or_mesh.geometry.values()))
    else:
        assert(isinstance(mesh, trimesh.Trimesh))
        mesh = scene_or_mesh
    return mesh

dRpath = "./test/LOGRNEW.txt"
dSpath = "./test/S.txt"

fileR = open(dRpath,"r")
R = fileR.readline()
R = fileR.readline()
R = [float(num) for num in R.split()]
print(np.array(R).reshape((-1, 3,3))[1])
R = expR(np.array(R).reshape((-1, 3,3)))
print(R[1])

fileS = open(dSpath,"r")
S = fileS.readline()
S = fileS.readline()
S = [float(num) for num in S.split()]
S = np.array(S).reshape((-1, 3,3))
print(S[0])


m_path = "./test1/1.obj"
d_path = "./test1/2.obj"
rmesh= as_mesh(trimesh.load(m_path, process=False))
dmesh= as_mesh(trimesh.load(d_path, process=False))
# v1, _, _, _ = load_obj(m_path)
# v2, _, _, _ = load_obj(d_path)
# dmesh_normals = trimesh.geometry.mean_vertex_normals(len(dmesh.vertices), dmesh.faces, dmesh.face_normals)

######## usage start ########
test = pyACAP.pyACAP(m_path)
t1=time.time()
#1: reference vertices N*3 
#2: deformed vertices  N*3
#3: output R(1) or logR(0)
#4: parallel for number of cores
R1, S1 = test.GetRS(rmesh.vertices, dmesh.vertices, 1,  os.cpu_count()//2)
t2=time.time()
print('deformed in {:0.2f}ms'.format((t2-t1)*1000.0))
######## usage end ########
print(R1.shape)
print(S1.shape)

print(R1.reshape((-1, 3,3))[1])
print(S1.reshape((-1, 3,3))[0])

residule_R = np.mean(np.abs(R1.reshape((-1, 3,3))-R))
residule_S = np.mean(np.abs(S1.reshape((-1, 3,3))-S))
print(residule_R, residule_S)








