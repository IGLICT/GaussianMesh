#include <pybind11/pybind11.h>
#include <pybind11/eigen.h>
#include <Eigen/Dense>
#include <string>
#include <iostream>
#include "src/FeatureVector.h"

namespace py = pybind11;

void updateMeshVertices(DTriMesh& mesh, const Eigen::MatrixXd& newVertices) {
    if (newVertices.cols() != 3 && newVertices.rows() != mesh.n_vertices()) {
        std::cerr << "Error: The Eigen matrix should have 3 columns and " << mesh.n_vertices() << " rows for vertex positions." << std::endl;
        return;
    }

    int vertexIndex = 0;
    for (DTriMesh::VertexIter v_it = mesh.vertices_begin(); v_it != mesh.vertices_end(); ++v_it) {
        DTriMesh::Point newVertex(newVertices(vertexIndex, 0), newVertices(vertexIndex, 1), newVertices(vertexIndex, 2));
        mesh.set_point(*v_it, newVertex);
        ++vertexIndex;
    }
}

class ACAP
{
    public:
        ACAP(const std::string &name) : name(name) {
            OpenMesh::IO::_OBJReader_();
            OpenMesh::IO::_OBJWriter_();
     
            meshes.resize(2);
            for (int i = 0; i < 2; i++)
            {
                DTriMesh *Meshori = new DTriMesh();
                if (!OpenMesh::IO::read_mesh(*Meshori, name.c_str()))
                {
                    std::cout << "Load reference Mesh Error" << std::endl;
                    return;
                }
                if (!Meshori[0].has_vertex_normals())
                {
                    Meshori[0].request_vertex_normals();
                    Meshori[0].request_face_normals();
                    Meshori[0].update_normals();
                    Meshori[0].release_face_normals(); // let the mesh update the normalss
                }
                meshes[i] = Meshori;
                
            }
            std::cout << "load " << name.c_str() << " success!!" << std::endl;

            this->ref = new RefMesh(meshes[0][0]);
        }
        ~ACAP() {
            delete ref;
            delete meshes[0];
            delete meshes[1];
        }

        std::pair<Eigen::MatrixXd, Eigen::MatrixXd> GetRS(const Eigen::MatrixXd & ref_array, 
                                               const Eigen::MatrixXd & deformed_array, bool _R, int cpunum) {
            updateMeshVertices(meshes[1][0], deformed_array);           
            return this->ref->GetRS(meshes[1][0], bool(_R), int(cpunum));
        }

    private:
        std::string name;
        RefMesh *ref;
        std::vector<DTriMesh*> meshes;
};


PYBIND11_MODULE(pyACAP, m) {
    // optional module docstring
    m.doc() = "pybind11 pyACAP plugin";

    // bindings to Pet class
    py::class_<ACAP>(m, "pyACAP")
        .def(py::init<const std::string &>())
        .def("GetRS", &ACAP::GetRS,
                        py::arg("ref_array"),
                        py::arg("deformed_array"),
                        py::arg("_R"), 
                        py::arg("cpunum"), pybind11::return_value_policy::reference_internal);
}




