# Available at setup time due to pyproject.toml
from pybind11.setup_helpers import Pybind11Extension, build_ext
from setuptools import setup
import os

__version__ = "0.0.1"

current_file_directory = os.path.dirname(os.path.abspath(__file__))

# The main interface is through Pybind11Extension.
# * You can add cxx_std=11/14/17, and then build_ext can be removed.
# * You can set include_pybind11=false to add the include directory yourself,
#   say from a submodule.
#
# Note:
#   Sort input source files if you glob sources to ensure bit-for-bit
#   reproducible builds (https://github.com/pybind/python_example/pull/53)

class CustomBuildExt(build_ext):
    def run(self):
        super().run()
        print(current_file_directory)
        # Specify the paths to the OpenMesh libraries
        openmesh_core_path = "cp " + current_file_directory + "/ACAP-build/OpenMesh-build/install-custom/lib/libOpenMeshCore.* "
        openmesh_tools_path = "cp " + current_file_directory + "/ACAP-build/OpenMesh-build/install-custom/lib/libOpenMeshTools.* "
        
        # Specify the target directory where the Python extension is located
        target_directory = os.path.dirname(self.get_ext_fullpath("ACAP"))

        # Copy OpenMesh libraries to the target directory
        os.system(openmesh_core_path + target_directory)
        os.system(openmesh_tools_path + target_directory)

ext_modules = [
    Pybind11Extension(
        "pyACAP",
        ["mainpy.cpp", "src/FeatureVector.cpp", "src/Align.cpp"],
        include_dirs=["3rd/Eigen", current_file_directory + '/ACAP-build/OpenMesh-build/install-custom/include'],
        define_macros=[("VERSION_INFO", __version__)],
        extra_compile_args=["-std=c++11", "-O2", "-fopenmp", "-shared", "-fPIC", "-W", "-undefined,dynamic_lookup"],
        libraries=["OpenMeshCore", "OpenMeshTools"],
        library_dirs=[current_file_directory + "/ACAP-build/OpenMesh-build/install-custom/lib"],
        extra_link_args=["-fopenmp","-Wl,-rpath,"+current_file_directory + "/ACAP-build/OpenMesh-build/install-custom/lib"],
    ),
]


setup(
    name="pyACAP",
    version=__version__,
    author="Jie",
    author_email="yj444757397@gmail.com",
    url="https://github.com/gaolinorange/Automatic-Unpaired-Shape-Deformation-Transfer/tree/master/ACAP_linux",
    description="import pyACAP; obj = pyACAP.pyACAP(m_path); R1, S1 = obj.GetRS(v1, v2)",
    long_description="",
    ext_modules=ext_modules,
    extras_require={"test": "pytest"},
    # Currently, build_ext only provides an optional "highest supported C++
    # level" feature, but in the future it may provide more features.
    cmdclass={"build_ext": CustomBuildExt},
    zip_safe=False,
    python_requires=">=3.8",
)