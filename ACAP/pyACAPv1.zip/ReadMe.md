# As-Consistent-As-Possible Deformation Representation (pyACAP)
The pybind implementation of ACAP, calculation of the deformation gradients of the deformed mesh related to reference.
Part of our sparse deformation [algorithm](https://arxiv.org/abs/1709.01250).

```
ACAP: Sparse Data Driven Mesh Deformation
Lin Gao, Yu-Kun Lai, Jie Yang, Ling-Xiao Zhang, Shihong Xia, Leif Kobbelt
IEEE Transactions on Visualization and Computer Graphics, 2019
```


## Dependencies
- [Blas & Lapack](https://www.netlib.org/lapack/lug/node11.html)
- [Eigen3](http://eigen.tuxfamily.org/index.php?title=Main_Page)
- [OpenMesh](https://www.openmesh.org/download/)

Note: we test the code on the OS platform with ```ubuntu 18.04.3, g++ 7.5, gcc 7.5, cmake 3.10.2```. All above the dependencies are provided, which are located in folder ```3rd```. Of course, you also could download them from theirs offical websites and complie them by yourself.

## ACAP Library

### 1. Blas & Lapack

Install the two libraries.
```sh
sudo apt-get install libopenblas-dev libblas-dev liblapack-dev
```

### 2. Install

```sh
git clone --recursive https://github.com/xxxxxx
cd ./ACAP_pybind
```

Then, run the scripts step by step. (You must make sure that each library is successfully installed)

```sh
 chmod +x install_OpenMesh.sh
 install_CoMISo.sh
 python setup.py install
```

### 4. Example

Usage: ```python test.py```

Output: Two files(```LOGRNEW.txt``` and ```S.txt```), which stored a matrix with size```1 * (V*9)``` respectively. Each row of file ```LOGRNEW.txt``` and ```S.txt``` represent the ACAP feature of a shape (For the detils of algorithm, please refer to sparse deformation [algorithm](https://arxiv.org/abs/1709.01250)). 

In order to check whether the code runs successfully, we provide a simple test example. In the folder ```test```, we also provide the GT ACAP feature files(```LOGRNEW.txt``` and ```S.txt```) for the three obj files ```1.obj, 2.obj```. You can check the code by comparing the output files with GT ACAP feature files. The output files can be obtained by the following command, the files will be stored in your input path.

```python
import ACAP, trimesh

m_path = "./test/1.obj"
d_path = "./test/2.obj"
rmesh= trimesh.load(m_path, process=False)
dmesh= trimesh.load(d_path, process=False)

obj = ACAP.ACAP(m_path)
R1, S1 = obj.GetRS(rmesh.vertices, dmesh.vertices)
```

## Citation

If you find this useful or use our code in your research, please cite our work by the following.

```
@article{gao2019sparse,
  title={Sparse data driven mesh deformation},
  author={Gao, Lin and Lai, Yu-Kun and Yang, Jie and Ling-Xiao, Zhang and Xia, Shihong and Kobbelt, Leif},
  journal={IEEE transactions on visualization and computer graphics},
  year={2019},
  publisher={IEEE}
}
```